//
//  RelationMapConfig.swift
//  UIBezierTest
//
//  Created by 安树杰 on 2019/5/21.
//  Copyright © 2019 安树杰. All rights reserved.
//

import Foundation
import UIKit

class RelationMapConfig {
    public var mainImgW:CGFloat? = 70//主要的Imgd的宽度
    public var mainStarModel:StarMessage?
    
    public var relationImgW:CGFloat? = 50//关系图上的Image的宽度
    public var relationArr:Array<StarMessage>?//联系人，后期数组里
    
    public var lineColor:UIColor? = UIColor.blue//连接线的颜色
    public var lineWidth:CGFloat? = 3.0//连接线的宽度
    public var lineTitleColor:UIColor? = UIColor.gray//连接线上字体的颜色
    public var lineTitleFont:UIFont? = UIFont.systemFont(ofSize: 14)//连接线上字体的大小
    
    public var relationNameColor:UIColor? = UIColor.gray//关系图上的字体的颜色
    public var relationNameFont:UIFont? = UIFont.systemFont(ofSize: 14)//关系图上字体的大小
}
class StarMessage{
    public var idStr:String?//艺人id
    public var name:String?//艺人头像
    public var headIco:String?//艺人姓名
    public var relationType:String?//关系类型
    public var relationCGPoint:CGPoint? = CGPoint()//定义图谱的位置
}

