//
//  CustomOvalView.swift
//  UIBezierTest
//
//  Created by 安树杰 on 2019/5/21.
//  Copyright © 2019 安树杰. All rights reserved.
//

import UIKit

protocol CustomOvalViewDelegate {
    
}
struct oval{
    var a:CGFloat = 0
    var b:CGFloat = 0
    
    func getCGPoint(angle:CGFloat,centerPoint:CGPoint) -> CGPoint{
        let getAngle:Double = 0-Double(angle/180.0)*(.pi)//角度转弧度
        let caculateAngle:CGFloat = atan2(self.a*CGFloat(sin(getAngle)),self.b*CGFloat(cos(getAngle)))//获取反向正切值
        return CGPoint(x: self.a*cos(caculateAngle)+centerPoint.x, y: self.b*sin(caculateAngle)+centerPoint.y)
    }
}
let spaceLimt:CGFloat = 20

class CustomOvalView: UIView {
    private var cornerRadius:CGPoint?
    private var mainStarBtn = UIButton(type: .custom)
    
    private var relationBtnArr:[CustomRelationBtn] = Array()
    private var relationLabArr:[CustomRelationLab] = Array()
    private var currentAngle:CGFloat = 0
    
    private var currectConfig:RelationMapConfig?
    private var bgOval:oval = oval()
    //实例话该view，内部维护一个椭圆形的，认为是位置坐标
    init(frame: CGRect,config:RelationMapConfig) {
        super.init(frame: frame)
        cornerRadius = CGPoint(x: frame.size.width/2.0, y: frame.size.height/2.0)
        self.currectConfig = config
        
        bgOval.a = (frame.size.width-2*spaceLimt)/2.0
        bgOval.b = (frame.size.height-2*spaceLimt)/2.0
        
        mainStarBtn.setImage(UIImage(named: config.mainStarModel!.headIco!), for: .normal)
        mainStarBtn.layer.borderWidth = 5
        mainStarBtn.layer.borderColor = UIColor.white.cgColor
        mainStarBtn.clipsToBounds = true
        addSubview(mainStarBtn)
        switch config.relationArr!.count {
        case 2:
            currentAngle = 180
        case 3,4:
            currentAngle = 90
        case 5,6:
            currentAngle = 45
        default:
            currentAngle = CGFloat(config.relationArr!.count == 0 ? 0:360/config.relationArr!.count)
        }
        for starMessage in config.relationArr! {
            let customBtn = CustomRelationBtn()
            let customLab = CustomRelationLab()
            customBtn.setName(name: starMessage.name!, img: UIImage(named:starMessage.headIco!)!)
            customLab.text = starMessage.relationType
            relationBtnArr.append(customBtn)
            relationLabArr.append(customLab)
            addSubview(customBtn)
            addSubview(customLab)
        }
    }
    override func draw(_ rect: CGRect) {
        let color = UIColor(red: 166/255, green: 164/255, blue: 241/255, alpha: 1.0)
        color.set()
        let aPath = UIBezierPath(ovalIn: CGRect(x: spaceLimt, y: spaceLimt, width: bounds.width-2*spaceLimt, height: bounds.height-2*spaceLimt))
        aPath.lineWidth = 3.0//线条宽度
        aPath.stroke()
        
        let linePath = UIBezierPath(rect: .zero)
        for index in 0..<currectConfig!.relationArr!.count {
            linePath.move(to: cornerRadius!)
            let customBtn = relationBtnArr[index] as CustomRelationBtn
            linePath.addLine(to: customBtn.center)
        }
        linePath.lineWidth = 3.0
        linePath.stroke()
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        mainStarBtn.frame = CGRect(x:0 , y: 0, width: currectConfig!.mainImgW!, height: currectConfig!.mainImgW!)
        mainStarBtn.layer.cornerRadius = mainStarBtn.width/2.0
        mainStarBtn.center = cornerRadius!
        for index in 0..<currectConfig!.relationArr!.count{
            let customBtn = relationBtnArr[index] as CustomRelationBtn
            let customLab = relationLabArr[index] as CustomRelationLab
            customBtn.frame = CGRect(x: 0, y: 0, width: currectConfig!.relationImgW!, height: currectConfig!.relationImgW!)
            customBtn.center = bgOval.getCGPoint(angle: CGFloat(index)*currentAngle, centerPoint: cornerRadius!)
            customLab.frame  = CGRect(x: 0, y: 0, width: 50, height: 15)
            customLab.center = getBazCenterPoint(starPoint: cornerRadius!, endPoind: customBtn.center)
            if  currectConfig!.relationArr!.count > 4&&currectConfig!.relationArr!.count < 7{
                customBtn.center = bgOval.getCGPoint(angle: CGFloat(index)*currentAngle + CGFloat(index/2)*45, centerPoint: cornerRadius!)
                customLab.center = getBazCenterPoint(starPoint: cornerRadius!, endPoind: customBtn.center)
                if currectConfig!.relationArr!.count == 6 && index >= 4{
                    customBtn.center = bgOval.getCGPoint(angle: 225 + CGFloat(index/5)*currentAngle + CGFloat(index/5)*45, centerPoint: cornerRadius!)
                    customLab.center = getBazCenterPoint(starPoint: cornerRadius!, endPoind: customBtn.center)
                }
            }
            let relationMessage = currectConfig!.relationArr![index] as StarMessage
            relationMessage.relationCGPoint = customBtn.center
        }
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
extension CustomOvalView{
    func getBazCenterPoint(starPoint:CGPoint,endPoind:CGPoint) -> CGPoint {
        var outCenterPoint:CGPoint = CGPoint()
        if endPoind.x > starPoint.x{
            outCenterPoint.x = CGFloat(fabsf(Float(endPoind.x-starPoint.x))/2.0)+starPoint.x
        }else{
            outCenterPoint.x = CGFloat(fabsf(Float(starPoint.x-endPoind.x))/2.0)+endPoind.x
        }
        
        if endPoind.y > starPoint.y{
             outCenterPoint.y = CGFloat(fabsf(Float(endPoind.y-starPoint.y))/2.0)+starPoint.y
        }else{
             outCenterPoint.y = CGFloat(fabsf(Float(starPoint.y-endPoind.y))/2.0)+endPoind.y
        }
        return outCenterPoint
    }
}
private class CustomRelationBtn:UIView{
    private var btn = UIButton(type: .custom)
    private var nameLabel = UILabel()
    override init(frame: CGRect) {
        super.init(frame: frame)
        btn.layer.borderWidth = 5
        btn.layer.borderColor = UIColor.white.cgColor
        btn.clipsToBounds = true
        addSubview(btn)
        
        nameLabel.backgroundColor = UIColor.white
        nameLabel.textAlignment = .center
        nameLabel.font = UIFont.systemFont(ofSize: 10)
        nameLabel.textColor = UIColor.black
        nameLabel.clipsToBounds = true
        addSubview(nameLabel)
    }
    func setName(name:String,img:UIImage){
         nameLabel.text = name
         btn.setImage(img, for: .normal)
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        btn.frame = CGRect(x:5 , y: 5, width: bounds.width-10, height: bounds.height-10)
        btn.layer.cornerRadius = btn.width/2.0
        
        nameLabel.frame = CGRect(x: 0, y: bounds.height-16, width: bounds.width, height: 12)
        nameLabel.layer.cornerRadius = nameLabel.height/2.0
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
private class CustomRelationLab:UILabel{
    override init(frame: CGRect) {
       super.init(frame: frame)
        self.backgroundColor = UIColor(red: 247/255, green: 247/255, blue: 247/255, alpha: 1)
        self.textColor = UIColor.gray
        self.textAlignment = .center
        self.layer.cornerRadius = 7.5
        self.clipsToBounds = true
        self.font = UIFont.systemFont(ofSize: 8)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
