//
//  ViewController.swift
//  UIBezierTest
//
//  Created by 安树杰 on 2019/5/21.
//  Copyright © 2019 安树杰. All rights reserved.
//

import UIKit
// 屏幕的宽度
let SCREEN_WIDTH = UIScreen.main.bounds.width
//屏幕的高度
let SCREEN_HEIGHT = UIScreen.main.bounds.height
class ViewController: UIViewController {
    private var config:RelationMapConfig?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        var arr:[StarMessage] = Array()
        for index in 0..<6{
            let starMessageModel = StarMessage()
            starMessageModel.relationType = "朋友"
            starMessageModel.name = "大安"
            starMessageModel.headIco = "timg"
            starMessageModel.relationCGPoint = CGPoint()
            arr.append(starMessageModel)
        }
        let mainMessage = StarMessage()
        mainMessage.headIco = "timg"
        mainMessage.name = "张艺兴"
        config = RelationMapConfig()
        config!.mainStarModel = mainMessage
        config!.relationArr = arr
        let oval = CustomOvalView(frame: CGRect(x: 13, y: 100, width:SCREEN_WIDTH-30, height:(3*SCREEN_WIDTH-30)/5.0),config: config!)
        view.addSubview(oval)
        
    }
}

